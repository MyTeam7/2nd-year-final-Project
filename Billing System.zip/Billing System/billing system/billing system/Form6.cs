﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Windows.Forms;

namespace billing_system
{
    public partial class Form6 : Form
    {
        public object frm;
        

        public Form6(object obj)
        {
            InitializeComponent();
            frm = obj;
            Billingform bf = (Billingform)frm;

        }
      
          
        private void Form6_Load(object sender, EventArgs e)
        {

            Billingform bf = new Billingform(); //(Billingform)obj;
            txtBoxCode.Text = bf.dataGridView1.Rows[bf.dataGridView1.CurrentCell.RowIndex].Cells[1].Value.ToString();
            txtBoxDescription.Text = bf.dataGridView1.Rows[bf.dataGridView1.CurrentCell.RowIndex].Cells[2].Value.ToString();
            textBox10.Text = bf.dataGridView1.Rows[bf.dataGridView1.CurrentCell.RowIndex].Cells[3].Value.ToString();
            
        }

        private void button5_Click(object sender, EventArgs e)
        {

        }

        private void button6_Click(object sender, EventArgs e)
        {
            this.Close();
        }
    }
}
